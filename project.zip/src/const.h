#ifndef CONST

#define CONST

#define CHAR_SIZE 256
#define ARR_SIZE 32

#endif