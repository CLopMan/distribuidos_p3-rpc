#!bin/bash

pdflatex-dev report.tex
pdflatex-dev report.tex
printf "\033[0;32mFINISH\033[0m\n"
