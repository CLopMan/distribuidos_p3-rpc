# distribuidos_p3-rpc
Implementación ejercicio evaluable 3
